#include <iostream>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <string>
#include <conio.h>
#include <windows.h>

using namespace std;

HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
COORD CursorPosition;

void gotoxy(int x, int y){
	CursorPosition.X = x;
	CursorPosition.Y = y;
	SetConsoleCursorPosition(console, CursorPosition);
}

void loading()
	//Prosedur untuk menambahkan loading screen sebelum masuk menu
{
	
	for(int a=1; a<=2; a++){
		system("cls");
		gotoxy(5,3);cout<<"=";
		Sleep(500);
		gotoxy(5,3);cout<<"==";
		Sleep(500);
		gotoxy(5,3);cout<<"===";
		Sleep(500);
		gotoxy(5,3);cout<<"====";
		Sleep(500);
		gotoxy(5,3);cout<<"=====";
		Sleep(500);	
	}
	
	gotoxy(5,3);cout<<"--SELAMAT BERMAIN--";
}

int main()
{
    system("color 5e");
    // Pilihan Player
    loading();
    int lagi, pilih;
    a:
	gotoxy(5,6);cout << "===================================" << endl;
    gotoxy(5,7);cout << " Selamat datang di GAME SUWIT JAWA " << endl;
    gotoxy(5,8);cout << "===================================" << endl << endl;
    gotoxy(5,9);cout << " Kamu Pilih ?" << "\n\n";
    gotoxy(5,10);cout << " 1. GAJAH" << "\n";
    gotoxy(5,11);cout << " 2. SEMUT" << "\n";
    gotoxy(5,12);cout << " 3. ORANG" << "\n";
    gotoxy(5,13);cout << " Silahkan Pilih  1/2/3 : => ";
    cin >> pilih;
    if(pilih==1)
    {
        gotoxy(5,16);cout << " Kamu = GAJAH" << endl;
        srand(time(NULL)); // bilangan random/acak
        int com = rand() % 10;
        if (com<=3 && com>=1)
            {
                gotoxy(5,17);cout << " Computer = GAJAH" << "\n\n";
                gotoxy(5,18);cout << " ==============" << endl;
                gotoxy(5,19);cout << " ==> SERI ! <==" << endl;
                gotoxy(5,20);cout << " ==============" << endl;
            }
        else if (com<=6 && com>=4)
            {
                gotoxy(5,17);cout << " Computer = ORANG" << "\n\n";
                gotoxy(5,18);cout << " =====================" << endl;
                gotoxy(5,19);cout << " ==> Kamu Menang ! <==" << endl;
                gotoxy(5,20);cout << " =====================" << endl;
            }
        else
            {
                gotoxy(5,17);cout << " Computer = SEMUT" << "\n\n";
                gotoxy(5,18);cout << " ====================" << endl;
                gotoxy(5,19);cout << " ==> Kamu Kalah ! <==" << endl;
                gotoxy(5,20);cout << " ====================" << endl;
            } cout << endl;
    }
    else if(pilih==2)
    {
        gotoxy(5,16);cout << " Kamu = SEMUT" << endl;
        srand(time(NULL));  // bilangan random/acak
        int com = rand() % 10;
        if (com<=3 && com>=1)
            {
                gotoxy(5,17);cout << " Computer = SEMUT" << "\n\n";
                gotoxy(5,18);cout << " ==============" << endl;
                gotoxy(5,19);cout << " ==> SERI ! <==" << endl;
                gotoxy(5,20);cout << " ==============" << endl;
            }
        else if (com<=6 && com>=4)
            {
                gotoxy(5,17);cout << " Computer = GAJAH" << "\n\n";
                gotoxy(5,18);cout << " =====================" << endl;
                gotoxy(5,19);cout << " ==> Kamu Menang ! <==" << endl;
                gotoxy(5,20);cout << " =====================" << endl;
            }
        else
            {
                gotoxy(5,17);cout << " Computer = ORANG" << "\n\n";
                gotoxy(5,18);cout << " ====================" << endl;
                gotoxy(5,19);cout << " ==> Kamu Kalah ! <==" << endl;
                gotoxy(5,20);cout << " ====================" << endl;
            } cout << endl;
    }
    else if(pilih==3)
    {
        gotoxy(5,16);cout << " Kamu = ORANG" << endl;
        srand(time(NULL));  // bilangan random/acak
        int com = rand() % 10;
        if (com<=3 && com>=1)
            {
                gotoxy(5,17);cout << " Computer = ORANG" << "\n\n";
                gotoxy(5,18);cout << " ==============" << endl;
                gotoxy(5,19);cout << " ==> SERI ! <==" << endl;
                gotoxy(5,20);cout << " ==============" << endl;
            }
        else if (com<=6 && com>=4)
            {
                gotoxy(5,17);cout << " Computer = SEMUT" << "\n\n";
                gotoxy(5,18);cout << " =====================" << endl;
                gotoxy(5,19);cout << " ==> Kamu Menang ! <==" << endl;
                gotoxy(5,20);cout << " =====================" << endl;
            }
        else
            {
                gotoxy(5,17);cout << " Computer = GAJAH" << "\n\n";
                gotoxy(5,18);cout << " ====================" << endl;
                gotoxy(5,19);cout << " ==> Kamu Kalah ! <==" << endl;
                gotoxy(5,20);cout << " ====================" << endl;
            } cout << endl;
    }
    else
    {
        gotoxy(5,17);cout << "yang anda input salah !!" << endl;
    }
    
    gotoxy(5,21);cout << "pilih lagi = [0] : ";
    cin >> lagi;b:

    if (lagi == 0)
    {
        system ("cls");
        goto a;
    }
}
